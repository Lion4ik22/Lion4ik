'use strict';

a = 15;
console.log(a);

let number = 5;
const leftBorderWidth = 1;

number = 10;
console.log(number);

const obj = {
a: 50
};

obj.a = 10;

console.log(obj);


console.log(name);
var name = 'Pavel';

{
    var result = 50;
}

console.log(result);

alert(5);
[].push('a');